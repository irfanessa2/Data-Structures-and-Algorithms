package dsa22.first;

import java.awt.Color;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class StudentWork {
  
  /** Implementation provided : DO NOT CHANGE THIS METHOD. */
  public static Collection<Color> distinctColoursUsingList(LoadedImage image) {
    List<Color> collection = new ArrayList<Color>(image.getWidth() * image.getHeight());
    for(int x = 0; x < image.getWidth(); x++) {
      for(int y = 0; y < image.getHeight(); y++) {
        Color c = image.getColor(x, y);
        if ( !collection.contains(c)) {
          collection.add(c);
        }
      }
    }
    return collection;
  }

  /** Student to provide implementation. */
  public static Collection<Color> distinctColoursUsingTreeSet(LoadedImage image) {
    System.out.println("You must code the method 'distinctColoursUsingTreeSet'!");
    return Collections.emptySortedSet();
  }

  /** Student to provide implementation. */
  public static Collection<Color> distinctColoursUsingHashSet(LoadedImage image) {
    System.out.println("You must code the method 'distinctColoursUsingHashSet'!");
    return Collections.emptySet();
  }

  /** Student to provide implementation. */
  public static Map<Color,Integer> frequencyCountUsingMap(LoadedImage image) {
    System.out.println("You must code the method 'frequencyCountUsingMap'!");
    return Collections.emptyMap(); 
  }

  /**  DO NOT CHANGE THIS METHOD */
  public static void main(String[] args) throws IOException {

    // ignores subdirectories in the target folder
    File[] files = new File("dsacw_images").listFiles(new FilenameFilter(){
      @Override
      public boolean accept(File dir, String name) {
        return new File(dir, name).isFile();
      }});
    Arrays.sort(files); // sorts by filenames which are numbered so that images are ordered by increasing size

    boolean suppressListCalculation = false; // set to true temporarily to skip the slow list computations 
    
    String[] summaries = new String[files.length + 1];
    summaries[0] = "image\tpixels\tunique\tlist\ttreeset\thashset\tfreqmap";
    
    int i = 1;
    for(File file : files) {
      LoadedImage image = new LoadedImage(file);   
      System.out.println( "IMAGE: " + image);

      StringBuilder summary = new StringBuilder(image.toString());
      long startTime, endTime, elapsed;
      Collection<Color> collection = Collections.emptyList();

      System.out.print("USING LIST:     ");
      if (!suppressListCalculation) {
        startTime = System.currentTimeMillis();
        collection = distinctColoursUsingList(image);
        endTime = System.currentTimeMillis();
        elapsed = endTime - startTime;
        System.out.print( collection.size() + " unique colours ");
        System.out.println( "identified in " + elapsed + " ms");
        summary.append("\t"); summary.append(collection.size());
        summary.append("\t"); summary.append(elapsed);
      } else {
        System.out.println("not done");
        summary.append("\tnot done");
        summary.append("\tnot done");        
      }
      
      System.out.print("USING TREE SET: ");
      startTime = System.currentTimeMillis();
      collection = distinctColoursUsingTreeSet(image);
      endTime = System.currentTimeMillis();
      elapsed = endTime - startTime;
      System.out.print( collection.size() + " unique colours ");
      System.out.println( "identified in " + elapsed + " ms");
      summary.append("\t"); summary.append(elapsed);

      System.out.print("USING HASH SET: ");
      startTime = System.currentTimeMillis();
      collection = distinctColoursUsingHashSet(image);
      endTime = System.currentTimeMillis();
      elapsed = endTime - startTime;
      System.out.print( collection.size() + " unique colours ");
      System.out.println( "identified in " + elapsed + " ms");
      summary.append("\t"); summary.append(elapsed);

      startTime = System.currentTimeMillis();
      Map<Color,Integer> map = frequencyCountUsingMap(image);
      endTime = System.currentTimeMillis();
      elapsed = endTime - startTime;
      System.out.println( "Frequency map generated in " + elapsed + " ms");
      summary.append("\t"); summary.append(elapsed);

      if ( i == 1) {
        Map<Color,Integer> sortedMap = Util.orderByValues(map);
        Util.showFrequencyCountLogarithmic(sortedMap, "First image computed");
      }

      summaries[i++] = summary.toString();     
    }
    
    System.out.println();
    for(String s : summaries) {
      System.out.println(s);
    }

  }

}
